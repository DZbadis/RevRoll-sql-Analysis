/*
Question #1:

Write a query to find the customer(s) with the most orders. 
Return only the preferred name.

Expected column names: preferred_name
*/

-- q1 solution:

WITH total_number_of_orders AS(SELECT COUNT(order_id) AS total_orders,customer_id,
 DENSE_RANK()OVER(ORDER BY COUNT(order_id) DESC) AS ran   
FROM orders
GROUP BY customer_id
)  
                      


SELECT preferred_name
FROM total_number_of_orders
LEFT JOIN customers
ON total_number_of_orders.customer_id=customers.customer_id
WHERE ran= 1 ;
 


/*
Question #2: 
RevRoll does not install every part that is purchased. 
Some customers prefer to install parts themselves. 
This is a valuable line of business 
RevRoll wants to encourage by finding valuable self-install customers and sending them offers.

Return the customer_id and preferred name of customers 
who have made at least $2000 of purchases in parts that RevRoll did not install. 

Expected column names: customer_id, preferred_name

*/

-- q2 solution:

SELECT orders.customer_id,preferred_name
FROM orders
LEFT JOIN installs
ON orders.order_id=installs.order_id
LEFT JOIN parts 
ON orders.part_id=parts.part_id
LEFT JOIN customers
ON orders.customer_id=customers.customer_id 
WHERE installs.order_id IS NULL
GROUP BY orders.customer_id,preferred_name
HAVING SUM(price*quantity)>=2000
ORDER BY orders.customer_id; 


/*
Question #3: 
Report the id and preferred name of customers who bought an Oil Filter and Engine Oil 
but did not buy an Air Filter since we want to recommend these customers buy an Air Filter.
Return the result table ordered by `customer_id`.

Expected column names: customer_id, preferred_name

*/

-- q3 solution:

WITH filter_or_engine_product AS(SELECT orders.customer_id, COUNT(DISTINCT(name)) 
                      AS filter_engine_purchases,
                      preferred_name
FROM orders
LEFT JOIN parts
ON orders.part_id = parts.part_id
LEFT JOIN customers ON orders.customer_id=customers.customer_id                                  
WHERE name ='Oil Filter'OR name='Engine Oil'
GROUP BY orders.customer_id,preferred_name
ORDER BY customer_id DESC)  ,
filter_and_engine_purchases AS(SELECT* FROM filter_or_engine_product
                               WHERE filter_engine_purchases =2)

SELECT filter_and_engine_purchases.customer_id,filter_and_engine_purchases.preferred_name
FROM filter_and_engine_purchases 
WHERE filter_and_engine_purchases.customer_id NOT IN( 
SELECT DISTINCT(filter_and_engine_purchases.customer_id) 
FROM filter_and_engine_purchases
LEFT JOIN orders
ON filter_and_engine_purchases.customer_id=orders.customer_id
LEFT JOIN parts
ON orders.part_id=parts.part_id
WHERE name ='Air Filter')
ORDER BY filter_and_engine_purchases.customer_id ASC;


/*
Question #4: 

Write a solution to calculate the cumulative part summary for every part that 
the RevRoll team has installed.

The cumulative part summary for an part can be calculated as follows:

- For each month that the part was installed, 
sum up the price*quantity in **that month** and the **previous two months**. 
This is the **3-month sum** for that month. 
If a part was not installed in previous months, 
the effective price*quantity for those months is 0.
- Do **not** include the 3-month sum for the **most recent month** that the part was installed.
- Do **not** include the 3-month sum for any month the part was not installed.

Return the result table ordered by `part_id` in ascending order. In case of a tie, order it by `month` in descending order. Limit the output to the first 10 rows.

Expected column names: part_id, month, part_summary
*/

-- q4 solution:

WITH monthly_istallement AS(SELECT orders.part_id,install_date,EXTRACT(MONTH FROM install_date) AS month,
                            SUM(quantity*price) AS installement_cost                 
FROM installs
LEFT JOIN orders
ON installs.order_id=orders.order_id
LEFT JOIN parts
ON orders.part_id=parts.part_id
GROUP BY orders.part_id,install_date
ORDER BY orders.part_id ASC,install_date DESC),

monthly_istallement_2 AS(SELECT part_id,month,SUM(installement_cost)AS installement_cost_2,
                         ROW_NUMBER() OVER(PARTITION BY part_id ORDER BY part_id ASC,month DESC ) 
                         AS month_rank 
FROM monthly_istallement
                         
GROUP BY part_id,month
ORDER BY part_id ASC,month DESC),

all_months AS(SELECT part_id, GENERATE_SERIES(1,12,1)AS months_series FROM parts),

t_1 AS(SELECT all_months.part_id,months_series,COALESCE(installement_cost_2,0)AS installement_cost_2,
month_rank
FROM all_months
LEFT JOIN monthly_istallement_2
ON all_months.months_series=monthly_istallement_2.month
AND all_months.part_id=monthly_istallement_2.part_id
ORDER BY all_months.part_id ASC,all_months DESC),

t_2 AS(SELECT part_id,months_series,month_rank,
SUM(installement_cost_2) 
OVER(ORDER BY part_id ASC,months_series ASC  
ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS part_sammary
FROM t_1
ORDER BY part_id ASC,months_series DESC )
SELECT part_id,months_series AS month,part_sammary
FROM t_2
WHERE month_rank>1
AND month_rank IS NOT NULL
LIMIT 10;


